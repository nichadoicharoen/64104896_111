import 'package:flutter_application_20/model/users.dart';

class Configure{
  static const server = "10.116.0.168:30000";
  static User login = User();
  static List<String> gender = [
    "None",
    "Male",
    "Female"
  ];
}